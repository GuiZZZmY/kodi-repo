# Arctic Fuse X

[![License](https://img.shields.io/badge/license-CC--BY--NC--SA%204.0-green)](http://creativecommons.org/licenses/by-nc-sa/4.0/)

A fork of **Arctic Fuse 2** by jurialmunkey, kept alive for Kodi 21 and 22, with
first-class support for emulator launchers.

Arctic Fuse 2 is deprecated upstream — development moved to
[Arctic Fuse 3](https://github.com/jurialmunkey/skin.arctic.fuse.3). This fork
is not a replacement for it and not a competitor to it. It exists because a
retro-gaming setup built on Advanced Emulator Launcher needed views that no
skin provides, and because a handful of small defects were worth fixing on the
version already in service.

**This is an unofficial fork.** Please do not report its bugs to jurialmunkey —
open an issue here instead.

<table>
  <tr>
    <td colspan="2">

<video src=".github/media/arctic-fuse-x.mp4" controls muted width="827"></video>

<div hidden>

https://github.com/user-attachments/assets/04ab7569-d3dd-432b-96c5-3277a9bac691

</div>

</td>
  </tr>
  <tr>
    <td><img src="resources/screenshots/00-splash.jpg" alt="Startup" width="400"></td>
    <td><img src="resources/screenshots/01-home.jpg" alt="Home" width="400"></td>
  </tr>
  <tr>
    <td><img src="resources/screenshots/05-launchers.jpg" alt="Emulator launchers" width="400"></td>
    <td><img src="resources/screenshots/03-movie-info.jpg" alt="Movie information" width="400"></td>
  </tr>
  <tr>
    <td><img src="resources/screenshots/06-album-info.jpg" alt="Album information" width="400"></td>
    <td><img src="resources/screenshots/07-artist-info.jpg" alt="Artist information" width="400"></td>
  </tr>
</table>

## What it adds

**Dedicated views for Advanced Emulator Launcher.** Four of them: a launcher
view for the console list, and three box-art views for ROMs — portrait, square
and landscape — because a SNES box, a Mega Drive box and an N64 box are not the
same shape, and forcing one grid on all three wastes the artwork.

**A settings dialog to assign them.** Each launcher gets its own view and its
own widget style, chosen from a dialog rather than edited by hand in
`guisettings.xml`. Create a launcher today, give it its views a minute later.
Needs the optional `script.aelviews` add-on.

**Widget styles, one added and one redrawn.** *LandscapePoster* is new: wide
artwork runs edge to edge, its title strip removed, so the image fills the tile
instead of sitting letterboxed inside it. *Quad* keeps its name but no longer
draws the upstream row — it is now a square tile, 296 by 296, which suits
artwork that is neither portrait nor wide. Nothing changes in how you pick it.

**Combined widgets.** A widget can take others under it. On the home screen
they share a single line of tabs in place of the title, and one row shows at a
time. Unlike the combined row of Arctic Fuse 3, whose tabs are the sub-folders
of one path, the tabs here are widgets in their own right: each has its own
source and its own style, and any widget can be combined or left alone. In the
widget settings, a button on the main widget's line attaches another, shown
indented beneath it — up to eight per main widget.

<table>
  <tr>
    <td><img src="resources/screenshots/09-combined-widgets.jpg" alt="Two combined widgets on the home screen, each with its line of tabs" width="400"></td>
    <td><img src="resources/screenshots/10-combined-widgets-settings.jpg" alt="The widget settings, attached widgets indented beneath their main widget" width="400"></td>
  </tr>
</table>

**An app bar, for use as a television launcher.** Favourites are shown as round
icons down the edge of the home screen, reachable with a single press of Left.
On an Android TV device this turns the skin into the front end for everything
else on the box: streaming apps, a browser, the store — all one keypress from
the library, without leaving Kodi.

<table>
  <tr>
    <td><img src="resources/screenshots/04-favourites.jpg" alt="The app bar" width="400"></td>
    <td><img src="resources/screenshots/11-launcher.jpg" alt="Kodi as the launcher of an Android TV device" width="400"></td>
  </tr>
</table>

**A local cast list in the video OSD.** Upstream fetches the cast from TMDb even
when the skin is set to prefer local metadata. This adds an option — off by
default — to read it from your own library instead, with the portraits you
already have and without a network round-trip. The crew section is deliberately
gone. Needs the optional `script.localcast` add-on.

**The season selector above its row.** In the combined views, where a TV
show's seasons and episodes share one screen, the season selector now sits
above the row it controls, underlined rather than boxed, where the section
label used to be. Up and Down follow a straight line — seasons, episodes, view
selector, and back — where upstream sent Up towards a list these views do not
have, so focus landed on whatever was nearest. A season with no plot of its own
shows the show's, which Kodi 22 no longer does by itself.

**Music information that shows what a local library actually holds.** Most
libraries carry no album reviews, so the album screen used to open on an empty
text box. An option — off by default — fills it with the artist's biography,
introduced by one line: *"Random Access Memories is an album by Daft Punk,
released in 2013."* The same text appears in album widgets and in the full
description box. The album screen keeps genre and label; the artist screen keeps
genre, type, birth or formation, and the label of the artist's latest album. The
cover now lines up with the top of the panel instead of a poster's foot.

**A glass background for the music visualisation.** Off by default, under
*Customise visualisation* in the music OSD: the background becomes the blurred
cover of the track playing. Nothing is computed by the skin — TMDb Helper
already blurs it on every track change and publishes the path, and it does so
in Pillow, which Kodi ships, so the effect is identical on every platform a
native visualisation would not reach. The blur radius is the existing skin
setting.

### Fixes

Three of these are plain bugs in Arctic Fuse 2. They are **not** being sent
upstream: Arctic Fuse 2 is no longer developed, and this fork is a separate
project rather than a staging area for it. They are fixed here, and described
here so anyone hitting the same bugs knows what was wrong.

- **RetroPlayer save dialogs were unusable.** The game-save list filled a
  different control from the one the dialog displayed, so it came up empty; the
  *New* button had no label; and empty labels showed around it.
- **The last item of a list stayed clipped.** The AEL views used `fixedlist`,
  which stops scrolling at the end and moves the cursor instead, leaving the
  final entry half off-screen. They use `list` now.
- Kodi 22 compatibility: the `SelectVideoVersion` checks removed in Kodi 22.

## Experimental: Arctic Fuse X on your iPhone

On a phone the television layout is unreadable, and hard to hit with a finger.
So a phone does not get a smaller copy of it: it gets an interface of its own,
drawn from the same elements and built for touch — one title per screen, swiped
sideways. **It is experimental**, and has been tuned on a single iPhone model
so far.

<table>
  <tr>
    <td><img src="resources/screenshots/08-iphone.png" alt="The phone interface: a movie, a TV show with its seasons and episodes, cast and recommendations" width="800"></td>
  </tr>
</table>

- **Made for a finger, not for a remote.** Round buttons, swipes instead of
  arrow keys, a strip of letters to jump through the list, and a player cut
  down to the playback buttons, audio and subtitles.
- **The library and nothing else.** Movies and TV shows. A movie plays, a TV
  show opens onto its seasons and episodes, and cast and recommendations are
  one tap away.
- **No skin settings, on purpose.** Colours and options are fixed, and the skin
  settings screen holds a single sentence saying so.
- **Nothing to switch on.** The skin picks this interface by itself on a 19.5:9
  display, and keeps the regular one everywhere else.

## Versions

| Branch  | Skin version | Kodi                | GUI ABI |
| ------- | ------------ | ------------------- | ------- |
| `omega` | 1.0.51        | 21 Omega            | 5.17.0  |
| `piers` | 1.1.51        | 22 Piers            | 5.18.0  |

## Installing

Install it from the add-on repository, not from a release zip: its
dependencies are only found through repositories.

Before you start, in **Settings → System → Add-ons**: enable *Unknown sources*,
and set *Updates* to **Any repositories**, as for every skin by jurialmunkey.

1. Download the `repository.guizmy` zip from
   [kodi-repo](https://github.com/GuiZZZmY/kodi-repo/tree/main/repository.guizmy),
   then **Add-ons → Install from zip file**.
2. **Install from repository → Dépôt GuiZmY → Add-on repository →
   jurialmunkey Alpha Repository**.
3. Restart Kodi, so that it reads jurialmunkey's repository.
4. **jurialmunkey Alpha Repository → Look and feel → Fonts → Roboto CJKSC**.
5. From **Dépôt GuiZmY → Look and feel → Skin**, install *Arctic Fuse X*. Its
   other dependencies install themselves.

### Optional add-ons

None of these are required. The skin runs without them; the features they back
simply stay inactive. Each one can be installed in one click from
**Skin settings → General → Dependencies**:

| Add-on | What it unlocks |
| ------ | --------------- |
| `plugin.program.advanced.emulator.launcher` | the emulator launchers themselves |
| `script.aelviews` | the per-launcher view and widget dialog |
| `script.localcast` | the local cast list in the OSD |

## Credits

All of the design, and nearly all of the code, is **jurialmunkey's**. Arctic
Fuse 2 is the original; this fork only adds to it. If you like the skin, support
the author — the link is in the upstream repository.

The Android robot is reproduced or modified from work created and shared by
Google and used according to terms described in the Creative Commons 3.0
Attribution License.

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0, unchanged from
upstream. See <http://creativecommons.org/licenses/by-nc-sa/4.0/>.
