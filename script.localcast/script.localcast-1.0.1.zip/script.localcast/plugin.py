# -*- coding: utf-8 -*-
"""Cast of the playing item, as the library knows it.

Kodi only populates a cast container inside its own info window: the skin simply
gives the control id 50 there and Kodi does the rest. No equivalent exists for a
custom window such as the OSD, where the only access to the playing item's cast
is VideoPlayer.Cast — a plain string, with no usable thumbnails or roles.

This plugin fills that gap: it asks the player what it is playing, looks the
matching record up in the library, and returns one item per actor, with role and
thumbnail. Nothing goes out to the network.

  plugin://script.localcast/

An item outside the library returns nothing — by design, there is no local cast
to show.
"""
import sys
import json
import xbmc
import xbmcgui
import xbmcplugin

# Each media type has its own method and result key. An episode carries its
# show's cast, which Kodi already fills in.
RECORDS = {
    "movie":   ("VideoLibrary.GetMovieDetails",   "movieid",   "moviedetails"),
    "episode": ("VideoLibrary.GetEpisodeDetails", "episodeid", "episodedetails"),
    "tvshow":  ("VideoLibrary.GetTVShowDetails",  "tvshowid",  "tvshowdetails"),
}


def jrpc(method, **params):
    answer = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
    try:
        return json.loads(answer).get("result") or {}
    except ValueError:
        return {}


def playing_cast():
    players = jrpc("Player.GetActivePlayers")
    if not isinstance(players, list) or not players:
        return []
    item = jrpc("Player.GetItem", playerid=players[0]["playerid"]).get("item") or {}

    record = RECORDS.get(item.get("type"))
    dbid = item.get("id")
    if not record or not dbid:
        return []

    method, id_key, result_key = record
    details = jrpc(method, **{id_key: dbid, "properties": ["cast"]})
    return (details.get(result_key) or {}).get("cast") or []


def run(handle):
    for actor in playing_cast():
        name = actor.get("name") or ""
        role = actor.get("role") or ""
        thumb = actor.get("thumbnail") or ""
        li = xbmcgui.ListItem(label=name, label2=role, offscreen=True)
        # the skin reads one or the other depending on the layout, so fill all three
        li.setArt({"thumb": thumb, "poster": thumb, "icon": thumb})
        li.setProperty("role", role)
        xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)
    xbmcplugin.setContent(handle, "actors")
    # no caching: the cast changes with every item played
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == "__main__":
    run(int(sys.argv[1]))
