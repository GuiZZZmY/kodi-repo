# -*- coding: utf-8 -*-
"""Cast of a library item, as the library knows it.

Kodi only populates a cast container inside its own info window: the skin simply
gives the control id 50 there and Kodi does the rest. No equivalent exists for a
custom window such as the OSD, where the only access to the playing item's cast
is VideoPlayer.Cast — a plain string, with no usable thumbnails or roles.

This plugin fills that gap: it asks the player what it is playing, looks the
matching record up in the library, and returns one item per actor, with role and
thumbnail. Nothing goes out to the network.

  plugin://script.localcast/

A skin that lists titles outside the info window is in the same position: it can
name the title it wants the cast of instead, by media type and library id.

  plugin://script.localcast/?type=movie&dbid=12
  plugin://script.localcast/?type=tvshow&dbid=34
  plugin://script.localcast/?type=episode&dbid=56

An item outside the library returns nothing — by design, there is no local cast
to show.
"""
import sys
import json
from urllib.parse import parse_qs
import xbmc
import xbmcgui
import xbmcplugin

# Each media type has its own method and result key. An episode carries its
# show's cast, which Kodi already fills in.
RECORDS = {
    "movie":   ("VideoLibrary.GetMovieDetails",   "movieid",   "moviedetails"),
    "episode": ("VideoLibrary.GetEpisodeDetails", "episodeid", "episodedetails"),
    "tvshow":  ("VideoLibrary.GetTVShowDetails",  "tvshowid",  "tvshowdetails"),
}


def jrpc(method, **params):
    answer = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
    try:
        return json.loads(answer).get("result") or {}
    except ValueError:
        return {}


def library_cast(media_type, dbid):
    record = RECORDS.get(media_type)
    if not record or not dbid:
        return []

    method, id_key, result_key = record
    details = jrpc(method, **{id_key: dbid, "properties": ["cast"]})
    return (details.get(result_key) or {}).get("cast") or []


def playing_cast():
    players = jrpc("Player.GetActivePlayers")
    if not isinstance(players, list) or not players:
        return []
    item = jrpc("Player.GetItem", playerid=players[0]["playerid"]).get("item") or {}
    return library_cast(item.get("type"), item.get("id"))


def requested_cast(query):
    """Cast of the title named in the plugin path, None when it names none."""
    params = parse_qs(query.lstrip("?"))
    media_type = (params.get("type") or [""])[0]
    dbid = (params.get("dbid") or [""])[0]
    if not media_type and not dbid:
        return None
    # a skin fills the id from an infolabel, which is empty while a list loads
    return library_cast(media_type, int(dbid)) if dbid.isascii() and dbid.isdigit() else []


def run(handle, query=""):
    cast = requested_cast(query)
    if cast is None:
        cast = playing_cast()
    for actor in cast:
        name = actor.get("name") or ""
        role = actor.get("role") or ""
        thumb = actor.get("thumbnail") or ""
        li = xbmcgui.ListItem(label=name, label2=role, offscreen=True)
        # the skin reads one or the other depending on the layout, so fill all three
        li.setArt({"thumb": thumb, "poster": thumb, "icon": thumb})
        li.setProperty("role", role)
        xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)
    xbmcplugin.setContent(handle, "actors")
    # no caching: the cast changes with every item played
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == "__main__":
    run(int(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else "")
