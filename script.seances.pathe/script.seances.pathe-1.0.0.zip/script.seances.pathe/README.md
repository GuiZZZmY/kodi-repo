# Séances Pathé

Extension Kodi qui affiche les **séances d'un film dans vos cinémas Pathé**, et
propose un **QR code** pour réserver depuis votre téléphone.

*[English version below](#pathé-showtimes)*

---

## Ce qu'elle fait

Le point d'entrée est le **film**, pas le cinéma. Sur n'importe quel film — dans
votre médiathèque, dans une liste TMDb, dans un widget de l'accueil — le menu
contextuel propose **Séances**.

S'il passe dans l'une de vos salles, vous choisissez le jour, puis la séance.
Chaque ligne indique l'heure, le cinéma, la salle quand elle est remarquable
(IMAX, 4DX, Dolby Cinéma) et le **tarif**.

La séance choisie affiche un QR code. Vous le scannez, votre téléphone ouvre la
page de réservation **sur cette séance précise**, et vous payez là où
l'authentification bancaire fonctionne.

S'il ne passe nulle part, l'extension le dit et s'arrête.

## Installation

Installez le zip depuis Kodi : **Extensions → Installer depuis un fichier zip**.
*Sources inconnues* doit être activé dans **Système → Extensions**.

Kodi 19 (Matrix) ou plus récent. La bibliothèque `script.module.pil`, livrée avec
Kodi, sert à composer le QR code — aucun service en ligne n'est sollicité.

## Réglages

Une seule chose à faire : **choisir vos salles**. Le bouton ouvre la liste des
cinémas Pathé, récupérée en direct ; vous cochez les vôtres.

Rien n'est codé en dur : la liste, les horaires et les tarifs viennent tous de
l'API publique de Pathé.

## Les tarifs sont indicatifs

Le plein tarif et les suppléments sont lus dans la fiche de chaque cinéma et
relus chaque jour. Une hausse de prix, ou une offre exceptionnelle ajoutée à la
grille, apparaît donc d'elle-même.

Le supplément (IMAX, 4DX, Dolby) est déduit du **nom de la salle**. En cas de
doute, l'extension n'applique aucun supplément : elle préfère afficher un prix
trop bas qu'un prix inventé. **Le prix affiché n'engage pas Pathé** — seule la
page de réservation fait foi.

## Ce qu'elle ne fait pas

Elle **n'achète pas** la place. Le paiement exige l'authentification forte
(3-D Secure), qui suppose un navigateur ou une application bancaire : cela ne se
fait pas dans Kodi, et l'on ne saisit pas un numéro de carte à la télécommande.
D'où le QR code.

Elle ne couvre **que les cinémas Pathé**. Les salles indépendantes ont chacune
leur système.

Le rapprochement entre le film sélectionné et le film à l'affiche se fait **sur
le titre**. Il peut échouer sur une réédition, ou sur un film que Pathé
orthographie autrement.

## Licence et mentions

MIT. Le QR code est produit par [python-qrcode](https://github.com/lincolnloop/python-qrcode)
(licence BSD), embarqué dans `resources/lib/qrcode`.

Extension **non officielle**, sans lien avec Pathé. Elle lit une API publique et
n'y écrit rien.

---

# Pathé Showtimes

A Kodi add-on showing **a film's showtimes in your Pathé cinemas**, with a
**QR code** to book from your phone.

Pathé is a French cinema chain; this add-on is only useful in France.

## What it does

The entry point is the **film**, not the cinema. On any film — in your library,
in a TMDb list, in a home widget — the context menu offers **Showtimes**.

If it plays in one of your cinemas, you pick the day, then the showtime. Each
line shows the time, the cinema, the auditorium when it is notable (IMAX, 4DX,
Dolby Cinema) and the **price**.

Choosing a showtime displays a QR code. Scan it and your phone opens the booking
page **for that exact showtime**, so you pay where bank authentication works.

If it plays nowhere, the add-on says so and stops.

## Installing

Install the zip from Kodi: **Add-ons → Install from zip file**. *Unknown sources*
must be enabled under **System → Add-ons**.

Kodi 19 (Matrix) or newer. `script.module.pil`, shipped with Kodi, is used to
draw the QR code — nothing is sent to any online service.

## Settings

One thing to do: **pick your cinemas**. The button opens the Pathé cinema list,
fetched live, and you tick yours.

Nothing is hardcoded: the list, the showtimes and the prices all come from Pathé's
public API.

## Prices are indicative

Full price and surcharges are read from each cinema's record and refreshed daily,
so a price rise — or a special offer added to the grid — shows up on its own.

The surcharge (IMAX, 4DX, Dolby) is inferred from the **auditorium name**. When
in doubt the add-on applies none: it would rather show a price that is too low
than one it invented. **The displayed price does not bind Pathé** — only the
booking page does.

## What it does not do

It does **not buy** the ticket. Payment requires strong customer authentication
(3-D Secure), which needs a browser or a banking app: that cannot happen inside
Kodi, and nobody types card details on a remote control. Hence the QR code.

It covers **Pathé cinemas only**. Independent cinemas each run their own system.

Matching the selected film to the one showing is done **by title**. It can fail
on a re-release, or on a film Pathé spells differently.

## License and credits

MIT. QR codes are produced by
[python-qrcode](https://github.com/lincolnloop/python-qrcode) (BSD licence),
vendored under `resources/lib/qrcode`.

**Unofficial** add-on, not affiliated with Pathé. It reads a public API and
writes nothing to it.
