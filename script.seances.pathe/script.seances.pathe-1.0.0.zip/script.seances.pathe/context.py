# -*- coding: utf-8 -*-
"""Entree de menu contextuel : les seances du film sous le curseur."""
import os
import sys

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "resources", "lib"))
import interface  # noqa: E402

if __name__ == "__main__":
    # On passe les deux titres sans choisir. Pathe etant francais, il ne connait
    # souvent que le titre de distribution : privilegier l'original faisait
    # echouer « L'Odyssee », que Kodi nomme « The Odyssey ».
    titres = [
        xbmc.getInfoLabel("ListItem.Title"),
        xbmc.getInfoLabel("ListItem.OriginalTitle"),
        xbmc.getInfoLabel("ListItem.Label"),
    ]
    annee = xbmc.getInfoLabel("ListItem.Year")
    # l'affiche et le synopsis sont repris tels quels : inutile de redemander a
    # Pathe ce que la mediatheque affiche deja mieux
    art = (xbmc.getInfoLabel("ListItem.Art(poster)")
           or xbmc.getInfoLabel("ListItem.Art(thumb)"))
    plot = xbmc.getInfoLabel("ListItem.Plot")
    interface.montrer_seances([t for t in titres if t], annee, art, plot)
