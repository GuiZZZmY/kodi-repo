# -*- coding: utf-8 -*-
"""
Client de l'API Pathe et rapprochement d'un film de la mediatheque avec un film
a l'affiche.

L'API est ouverte : ni cle, ni jeton, ni entete particulier. Quatre points
d'acces suffisent :

    /api/cinemas                          les salles, avec leur slug
    /api/cinema/<salle>/shows             les films a l'affiche : { days, shows }
    /api/show/<film>                      la fiche d'un film
    /api/show/<film>/showtimes/<salle>    les horaires, par date

Le point important : `shows` est indexe PAR FILM, pas par seance. C'est ce qui
permet d'entrer par le film plutot que par le cinema.

Chaque seance porte un `refCmd` — l'URL de reservation de cette seance-la. C'est
elle qu'on met dans le QR code : le telephone ouvre le choix des places, la
seance deja selectionnee.
"""

import json
import os
import re
import time
import unicodedata
import urllib.request

BASE = "https://www.pathe.fr/api"

# /!\ L'agent utilisateur n'est pas decoratif. Avec un agent explicite du genre
# "Kodi/script.seances.pathe", /api/cinemas et /api/cinema/<salle>/shows repondent
# normalement, mais /showtimes/ renvoie un 403. Il faut un agent de navigateur.
ENTETES = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/17.0 Safari/605.1.15"
    ),
    "Accept": "application/json",
}

# Les films a l'affiche ne changent qu'une fois par jour ; la liste des salles,
# quasiment jamais. On evite de solliciter Pathe a chaque ouverture d'un menu.
# La fiche d'une salle porte ses TARIFS : on la relit chaque jour, pour qu'une
# hausse ou une offre exceptionnelle suive d'elle-meme. Rien n'est fige ici.
PEREMPTION = {"cinemas": 7 * 86400, "cinema": 86400,
              "shows": 6 * 3600, "showtimes": 3600}


class ErreurReseau(Exception):
    """Pathe injoignable ou reponse illisible. Remonte telle quelle a l'appelant,
    qui saura l'afficher — le module ne parle pas a l'utilisateur."""


def _lire(url, cache_dir, genre):
    """Recupere une URL, avec un cache sur disque date par `genre`."""
    nom = re.sub(r"[^a-zA-Z0-9._-]", "_", url.replace(BASE + "/", "")) + ".json"
    chemin = os.path.join(cache_dir, nom)

    if os.path.exists(chemin):
        age = time.time() - os.path.getmtime(chemin)
        if age < PEREMPTION.get(genre, 3600):
            try:
                with open(chemin, encoding="utf-8") as f:
                    return json.load(f)
            except (ValueError, OSError):
                pass  # cache corrompu : on retelecharge plutot que d'echouer

    try:
        requete = urllib.request.Request(url, headers=ENTETES)
        with urllib.request.urlopen(requete, timeout=15) as reponse:
            donnees = json.loads(reponse.read().decode("utf-8"))
    except Exception as erreur:
        # Le reseau est tombe mais on a peut-etre une copie perimee : mieux vaut
        # des horaires d'hier qu'un message d'erreur.
        if os.path.exists(chemin):
            try:
                with open(chemin, encoding="utf-8") as f:
                    return json.load(f)
            except (ValueError, OSError):
                pass
        raise ErreurReseau(str(erreur))

    try:
        os.makedirs(cache_dir, exist_ok=True)
        with open(chemin, "w", encoding="utf-8") as f:
            json.dump(donnees, f)
    except OSError:
        pass  # cache non ecrit : sans consequence, on a les donnees

    return donnees


def cinemas(cache_dir):
    """Toutes les salles Pathe : [(slug, nom, ville), ...], triees par nom."""
    donnees = _lire(BASE + "/cinemas", cache_dir, "cinemas")
    salles = [
        (c.get("slug"), c.get("name") or c.get("slug"), c.get("citySlug") or "")
        for c in donnees
        if c.get("slug")
    ]
    return sorted(salles, key=lambda s: s[1])


def cinema(salle, cache_dir):
    """La fiche d'une salle : nom, tarifs, supplements, alertes."""
    return _lire("%s/cinema/%s" % (BASE, salle), cache_dir, "cinema")


def films_a_l_affiche(salle, cache_dir):
    """Les identifiants des films projetes dans une salle."""
    donnees = _lire("%s/cinema/%s/shows" % (BASE, salle), cache_dir, "shows")
    return list((donnees.get("shows") or {}).keys())


def fiche(film, cache_dir):
    """La fiche d'un film : titre, titre original, date de sortie, duree..."""
    return _lire("%s/show/%s" % (BASE, film), cache_dir, "shows")


def horaires(film, salle, cache_dir):
    """Les seances d'un film dans une salle, groupees par date.

    Retourne { "2026-08-18": [seance, ...], ... }, chaque seance portant
    `time`, `version`, `tags`, `auditoriumName` et `refCmd`.
    """
    return _lire(
        "%s/show/%s/showtimes/%s" % (BASE, film, salle), cache_dir, "showtimes"
    )


# --- rapprochement avec un film de la mediatheque ---------------------------

# Les mentions que Pathe accole aux titres et qui n'existent pas cote TMDb.
_MENTIONS = re.compile(
    r"\b(vf|vost|vostfr|imax|4dx|dolby|atmos|3d|version longue|"
    r"director'?s cut|redux|le film)\b",
    re.IGNORECASE,
)


def normaliser(titre):
    """Ramene un titre a une forme comparable.

    Les accents, la ponctuation, les articles initiaux et les mentions de format
    sont autant de facons dont deux catalogues ecrivent le meme film. On les
    efface tous plutot que d'esperer une egalite stricte.
    """
    if not titre:
        return ""
    t = unicodedata.normalize("NFD", str(titre))
    t = "".join(c for c in t if unicodedata.category(c) != "Mn").lower()
    t = _MENTIONS.sub(" ", t)
    # l'article initial saute, qu'il soit suivi d'une espace ou d'une apostrophe
    t = re.sub(r"^(le|la|les|un|une|des|the|a|an)\s+|^[ld]['\u2019]", "", t.strip())
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def _annee(fiche_film):
    """L'annee de sortie francaise, ou 0 si Pathe ne la donne pas."""
    sortie = fiche_film.get("releaseAt") or {}
    if isinstance(sortie, dict):
        sortie = sortie.get("FR_FR") or next(iter(sortie.values()), "")
    correspondance = re.search(r"(19|20)\d{2}", str(sortie))
    return int(correspondance.group(0)) if correspondance else 0


def chercher(titres, annee, salles, cache_dir):
    """Cherche l'un des `titres` a l'affiche dans `salles`.

    Retourne (identifiant_film, fiche, [salles ou il passe]) ou (None, None, []).

    On compare le titre normalise au titre ET au titre original — un film
    etranger est souvent range sous l'un cote Kodi et sous l'autre cote Pathe.
    L'annee ne sert qu'a departager deux homonymes, avec deux ans de tolerance :
    une sortie salle francaise decale souvent l'annee de production.
    """
    if isinstance(titres, str):
        titres = [titres]
    # Kodi propose souvent deux titres : le traduit et l'original. Pathe etant un
    # site francais, il ne connait parfois que le premier — d'ou l'echec si l'on
    # choisit. On essaie donc les deux, sans presumer lequel correspondra.
    cibles = [c for c in (normaliser(t) for t in titres if t) if c]
    if not cibles:
        return None, None, []

    # un film passe souvent dans plusieurs salles : on retient toutes celles-la
    par_film = {}
    for salle in salles:
        try:
            for film in films_a_l_affiche(salle, cache_dir):
                par_film.setdefault(film, []).append(salle)
        except ErreurReseau:
            continue  # une salle injoignable ne doit pas condamner les autres

    exacts, approches = [], []
    for film, ou in par_film.items():
        # le slug porte le titre : premier filtre, gratuit, avant tout appel
        slug = normaliser(film)
        if not any(c.split()[0] in slug for c in cibles):
            continue
        try:
            f = fiche(film, cache_dir)
        except ErreurReseau:
            continue
        cotes_pathe = {normaliser(f.get("title")), normaliser(f.get("originalTitle"))}
        if not (cotes_pathe & set(cibles)):
            continue
        a = _annee(f)
        if annee and a and abs(a - int(annee)) > 2:
            approches.append((film, f, ou))
        else:
            exacts.append((film, f, ou))

    trouve = exacts or approches
    return trouve[0] if trouve else (None, None, [])
