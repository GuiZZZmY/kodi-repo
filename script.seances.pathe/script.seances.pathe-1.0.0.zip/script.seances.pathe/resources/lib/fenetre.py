# -*- coding: utf-8 -*-
"""La fenetre flottante des seances.

Une seule rangee horizontale, qui sert d'abord les jours puis, le jour valide,
ses horaires. Retour revient aux jours plutot que de fermer — c'est ce qu'on
attend d'un retour, et ca evite de ressortir pour changer de jour.

L'affiche et le synopsis viennent de l'element d'origine, pas de Pathe : la
mediatheque et TMDbHelper les ont deja, en meilleure qualite et dans la langue
de l'interface. Le fond flou aussi : le skin l'a deja calcule, la fenetre se
contente de le lire.
"""

import xbmcgui

LISTE = 500

ACTIONS_RETOUR = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)

JOURS = 0
HORAIRES = 1


class FenetreSeances(xbmcgui.WindowXMLDialog):
    """Rendue par resources/skins/Default/1080i/DialogSeances.xml."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.par_jour = kwargs["par_jour"]
        self.jours = kwargs["jours"]
        self.libelle_jour = kwargs["libelle_jour"]
        self.ligne = kwargs["ligne"]
        self.date_courte = kwargs["date_courte"]
        self.soustitre = kwargs["soustitre"]
        self.detail = kwargs["detail"]
        self.sur_choix = kwargs["sur_choix"]
        self.entete_jours = kwargs["entete_jours"]
        self.etape = JOURS
        self.seances = []

    def onInit(self):  # noqa: N802 (nom impose par Kodi)
        self._montrer_jours()

    # --- les deux ecrans -----------------------------------------------------

    def _poser(self, elements, entete):
        liste = self.getControl(LISTE)
        liste.reset()
        for principal, secondaire, soustitre in elements:
            item = xbmcgui.ListItem(principal, secondaire)
            # le sous-titre de la carte suit le curseur : il est porte par
            # l'element, la fenetre n'a rien a recalculer
            item.setProperty("soustitre", soustitre)
            liste.addItem(item)
        self.setProperty("entete", entete)
        self.setFocusId(LISTE)

    def _montrer_jours(self):
        """Jour en haut de tuile, date en dessous.

        Deux lignes comme les horaires : la tuile garde la meme hauteur d'un
        ecran a l'autre, donc la capsule du focus reste bien cadree.
        """
        self.etape = JOURS
        elements = [(self.libelle_jour(j), self.date_courte(j), "")
                    for j in self.jours]
        self._poser(elements, self.entete_jours)

    def _montrer_horaires(self, jour):
        self.etape = HORAIRES
        self.seances = sorted(self.par_jour[jour],
                              key=lambda e: e[0].get("time") or "")
        elements = []
        for seance, nom, detail in self.seances:
            heure = (seance.get("time") or "")[11:16]
            # `detail` et non `ligne` : la ligne complete recommence par
            # l'heure, qui est deja le libelle principal de la tuile
            elements.append((heure, self.detail(seance, nom),
                             self.soustitre(seance, nom, detail)))
        self._poser(elements, self.libelle_jour(jour))

    # --- interactions --------------------------------------------------------

    def onAction(self, action):  # noqa: N802
        code = action.getId()
        if code in ACTIONS_RETOUR:
            if self.etape == HORAIRES:
                self._montrer_jours()     # retour aux jours, pas fermeture
            else:
                self.close()
            return
        # La validation n'est traitee QUE dans onClick : Kodi appelle les deux
        # pour un meme appui, et valider ici enchainait le choix du jour puis
        # celui de l'horaire en une seule pression.

    def onClick(self, control):  # noqa: N802
        if control == LISTE:
            self._valider()

    def _valider(self):
        index = self.getControl(LISTE).getSelectedPosition()
        if index < 0:
            return
        if self.etape == JOURS:
            if index < len(self.jours):
                self._montrer_horaires(self.jours[index])
        elif index < len(self.seances):
            # On NE FERME PAS : la fenetre reste dessous pendant que le QR
            # s'ouvre au-dessus. La fermer d'abord laissait apparaitre l'ecran
            # nu entre les deux, et le flou clignotait.
            self.sur_choix(self.seances[index][0])


def ouvrir(addon_path, titre, affiche, synopsis, **kwargs):
    """Ouvre la fenetre. Chaque seance retenue est passee a `sur_choix`.

    La fenetre ne rend plus la main sur un choix : elle reste ouverte pendant
    que le QR s'affiche au-dessus, puis on y revient. On peut donc enchainer
    plusieurs seances sans tout rouvrir.
    """
    fenetre = FenetreSeances("DialogSeances.xml", addon_path, "Default", "1080i",
                             **kwargs)
    fenetre.setProperty("titre", titre or "")
    fenetre.setProperty("affiche", affiche or "")
    fenetre.setProperty("synopsis", synopsis or "")
    fenetre.doModal()
    del fenetre


class FenetreQR(xbmcgui.WindowXMLDialog):
    """Le QR, en fenetre de skin : meme fond et memes animations que la liste.

    Une fenetre creee en Python n'a ni l'un ni l'autre — c'est la seule raison
    de ce passage par un XML.
    """

    def onAction(self, action):  # noqa: N802
        self.close()

    def onClick(self, control):  # noqa: N802
        self.close()


def montrer_qr(addon_path, chemin, titre, instruction, ligne1, ligne2):
    """Les textes arrivent en proprietes : $LOCALIZE, dans une fenetre de skin,
    resout contre le skin et non contre l'extension."""
    fenetre = FenetreQR("DialogQR.xml", addon_path, "Default", "1080i")
    fenetre.setProperty("qr", chemin or "")
    fenetre.setProperty("titre", titre or "")
    fenetre.setProperty("instruction", instruction or "")
    fenetre.setProperty("ligne1", ligne1 or "")
    fenetre.setProperty("ligne2", ligne2 or "")
    fenetre.doModal()
    del fenetre
