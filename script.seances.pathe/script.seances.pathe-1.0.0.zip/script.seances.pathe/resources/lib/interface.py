# -*- coding: utf-8 -*-
"""Ce que l'utilisateur voit : choix des salles, liste des seances, QR code."""

import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fenetre  # noqa: E402
import pathe  # noqa: E402

ADDON = xbmcaddon.Addon()
NOM = ADDON.getAddonInfo("name")


def _t(numero):
    return ADDON.getLocalizedString(numero)


def dossier_donnees():
    chemin = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not os.path.isdir(chemin):
        os.makedirs(chemin, exist_ok=True)
    return chemin


def vostfr_visible():
    """Les seances en version originale sous-titree sont-elles affichees ?

    Masquees par defaut : la majorite des seances etant en VF, les melanger
    allonge la liste sans servir a qui ne les cherche pas.
    """
    return ADDON.getSettingBool("vostfr")


def salles_choisies():
    brut = ADDON.getSetting("salles") or ""
    return [s for s in brut.split(",") if s]


# --- choix des salles -------------------------------------------------------


def choisir_salles():
    """Liste a cocher alimentee par le catalogue Pathe en direct.

    C'est ce qui rend l'extension partageable : rien n'est code en dur, chacun
    coche ses cinemas.
    """
    cache = dossier_donnees()
    progres = xbmcgui.DialogProgressBG()
    progres.create(NOM, _t(32002))
    try:
        catalogue = pathe.cinemas(cache)
    except pathe.ErreurReseau as erreur:
        progres.close()
        xbmcgui.Dialog().ok(NOM, "%s\n\n%s" % (_t(32005), erreur))
        return
    finally:
        progres.close()

    deja = salles_choisies()
    libelles = ["%s — %s" % (nom, ville) if ville else nom
                for _, nom, ville in catalogue]
    presel = [i for i, (slug, _, _) in enumerate(catalogue) if slug in deja]

    choix = xbmcgui.Dialog().multiselect(_t(32011), libelles, preselect=presel)
    if choix is None:
        return  # annule : on ne touche pas au reglage existant

    slugs = [catalogue[i][0] for i in choix]
    noms = [catalogue[i][1] for i in choix]
    ADDON.setSetting("salles", ",".join(slugs))
    ADDON.setSetting("salles_libelle", ", ".join(noms))
    # Confirmation immediate : la page de reglages n'affiche pas la selection,
    # le contrôle « label » n'etant pas rendu par tous les skins.
    xbmcgui.Dialog().notification(
        NOM, ", ".join(noms) if noms else _t(32004), xbmcgui.NOTIFICATION_INFO, 4000)


# --- affichage des seances --------------------------------------------------


# Les tags qui changent la seance pour le spectateur. Volontairement court :
# « pmr » est present sur presque toutes les seances et n'apprend rien, « DEFAULT »
# et « GRETA » sont internes a Pathe.
TAGS_PARLANTS = {"atmos": "Atmos", "dolby": "Dolby", "imax": "IMAX",
                 "4dx": "4DX", "GPXP": "Premium", "live": "En direct"}


def _ligne(seance, nom_salle=None, detail=None):
    """Une seance en une ligne courte : 14:30 · Docks 76 · salle 7 · Atmos.

    La fenetre de selection de Kodi tronque au-dela d'une certaine longueur ;
    tout ce qui n'aide pas a choisir est donc ecarte. La version n'apparait que
    si ce n'est pas de la VF, qui est le cas courant.
    """
    morceaux = [(seance.get("time") or "")[11:16]]
    if nom_salle:
        morceaux.append(nom_salle)
    version = (seance.get("version") or "").lower()
    if version and version != "vf":
        morceaux.append(version.upper())
    salle = (seance.get("auditoriumName") or "").strip()
    # Le numero de salle n'apprend rien avant d'etre sur place. Une salle NOMMEE,
    # elle, change la seance et justifie le supplement : on la garde.
    if salle and not salle.isdigit():
        morceaux.append(salle)
    deja = salle.lower()
    salle_nommee = bool(salle) and not salle.isdigit()
    for tag in seance.get("tags") or []:
        libelle = TAGS_PARLANTS.get(tag)
        # ne pas ecrire « 4DX · 4DX » : le nom de salle porte parfois deja le tag
        if not libelle or libelle.lower() in deja:
            continue
        # « Premium » est implicite dans DOLBY CINEMA, IMAX ou 4DX
        if libelle == "Premium" and salle_nommee:
            continue
        morceaux.append(libelle)
    if detail:
        plein = _plein_tarif(detail)
        if plein:
            morceaux.append(_euros(plein + _supplement(detail, seance)[1]))
    return " · ".join(morceaux)


def _euros(centimes):
    """1510 -> « 15,10 € ». L'API compte en centimes."""
    return ("%.2f" % (centimes / 100.0)).replace(".", ",") + " €"


def _plein_tarif(detail):
    """Le plein tarif de la salle, en centimes, ou None s'il n'est pas donne.

    On ne devine pas : on cherche l'entree dont le libelle porte « plein », et a
    defaut on prend la plus chere de la grille. Si la grille est vide, on
    n'affiche pas de prix plutot que d'en inventer un.
    """
    grille = detail.get("prices") or []
    if not grille:
        return None
    for entree in grille:
        if "plein" in (entree.get("label") or "").lower():
            return entree.get("price")
    return max((e.get("price") or 0) for e in grille) or None


def _supplement(detail, seance):
    """Le supplement applicable a une seance, d'apres le nom de sa salle.

    Rapprochement de chaines, donc faillible — c'est assume, l'affichage est
    indicatif. En cas de doute on ne majore pas : mieux vaut un prix trop bas
    qu'un prix invente.
    """
    salle = (seance.get("auditoriumName") or "").lower()
    if not salle:
        return None, 0
    en_3d = any("3d" in str(x).lower() for x in (seance.get("tags") or []))
    meilleur = (None, 0)
    for entree in (detail.get("additionalPrices") or {}).values():
        libelle = (entree.get("label") or "").lower()
        # le mot distinctif du supplement doit figurer dans le nom de la salle
        distinctifs = [m for m in ("dolby", "imax", "4dx") if m in libelle]
        if not distinctifs or not any(m in salle for m in distinctifs):
            continue
        # /!\ « Imax hors 3D » contient « 3d » et designe pourtant le contraire.
        # Un simple test d'inclusion facturait le plein tarif sur les seances IMAX.
        supplement_3d = "3d" in libelle and "hors 3d" not in libelle
        if supplement_3d != en_3d:
            continue
        if (entree.get("price") or 0) > meilleur[1]:
            meilleur = (entree.get("label"), entree.get("price") or 0)
    return meilleur


def _detail_tuile(seance, nom_salle):
    """Ce qui accompagne l'heure sur une tuile : salle nommee, version, labels.

    L'heure en est volontairement absente — elle est deja le libelle principal,
    la repeter l'affichait deux fois.
    """
    complet = _ligne(seance, nom_salle)
    _, _, reste = complet.partition(" · ")
    return reste


def _soustitre(seance, nom_salle, detail):
    """Ce qui s'affiche sous le titre : le cinema et le prix.

    C'est la place ou un skin met d'ordinaire le genre et la note — inutiles ici,
    on sait deja quel film on regarde. Ce qu'on cherche, c'est ou et combien.
    """
    morceaux = [m for m in (nom_salle,) if m]
    if detail:
        plein = _plein_tarif(detail)
        if plein:
            morceaux.append(_euros(plein + _supplement(detail, seance)[1]))
    return "  ·  ".join(morceaux)


def _nom_court(nom):
    """« Pathé Grand-Quevilly » -> « Grand-Quevilly ». L'enseigne est la meme
    partout, la repeter a chaque ligne mange la place utile."""
    for prefixe in ("Pathé ", "Gaumont ", "Pathe "):
        if nom.startswith(prefixe):
            return nom[len(prefixe):]
    return nom


def _date_courte(iso):
    """2026-08-18 -> « 18 août ». Complete le nom du jour sur la tuile."""
    import datetime

    try:
        d = datetime.date(*[int(x) for x in iso.split("-")])
    except (ValueError, TypeError):
        return ""
    mois = ["janv.", "févr.", "mars", "avril", "mai", "juin", "juil.",
            "août", "sept.", "oct.", "nov.", "déc."]
    return "%d %s" % (d.day, mois[d.month - 1])


def _jour_lisible(iso):
    """2026-08-18 -> « lun. 18 août », et « Aujourd'hui » / « Demain »."""
    import datetime

    try:
        d = datetime.date(*[int(x) for x in iso.split("-")])
    except (ValueError, TypeError):
        return iso
    ecart = (d - datetime.date.today()).days
    if ecart == 0:
        return "Aujourd'hui"
    if ecart == 1:
        return "Demain"
    jours = ["lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim."]
    mois = ["janv.", "févr.", "mars", "avril", "mai", "juin", "juil.",
            "août", "sept.", "oct.", "nov.", "déc."]
    return "%s %d %s" % (jours[d.weekday()], d.day, mois[d.month - 1])


# Le liseré reprend le rose du focus d'Arctic Fuse : le QR se lit alors comme un
# element selectionne, pas comme une image collee par-dessus l'interface.
ROSE_FOCUS = (233, 30, 122)
VOILE = (0, 0, 0, 205)          # assez opaque pour detacher, assez clair pour situer
COTE = 600                      # cote de l'image composee, en pixels reels
PART_HAUTEUR = 0.46             # part de la hauteur du canevas occupee par la carte


def _png_uni(chemin, taille, couleur):
    """Ecrit un PNG d'une seule couleur. Sert de voile plein ecran."""
    from PIL import Image

    Image.new("RGBA", taille, couleur).save(chemin)
    return chemin


# Ratio de l'affiche dans la fiche d'information du skin : 560 / 820.
RATIO_AFFICHE = 560.0 / 820.0


def _nom_cache(prefixe, graine):
    """Un nom de fichier propre a son contenu.

    /!\ Kodi met ses textures en cache PAR CHEMIN. Reecrire toujours le meme
    fichier lui faisait resservir l'ancienne image : l'affiche restait celle du
    film precedent, et — bien plus grave — le QR celui de la seance precedente,
    donc une reservation sur le mauvais horaire.
    """
    import hashlib

    empreinte = hashlib.md5(str(graine).encode("utf-8")).hexdigest()[:16]
    return "%s-%s.png" % (prefixe, empreinte)


def _menage_cache(cache, prefixe, garder=24):
    """Ne conserve que les derniers fichiers d'un prefixe donne."""
    try:
        fichiers = [f for f in os.listdir(cache)
                    if f.startswith(prefixe + "-") and f.endswith(".png")]
        fichiers.sort(key=lambda f: os.path.getmtime(os.path.join(cache, f)),
                      reverse=True)
        for vieux in fichiers[garder:]:
            os.remove(os.path.join(cache, vieux))
    except OSError:
        pass


def _charger_image(source):
    """Ouvre une image, qu'elle vienne du web ou du disque. None si impossible."""
    import io

    from PIL import Image

    if not source:
        return None
    try:
        if source.startswith(("http://", "https://")):
            import urllib.request

            requete = urllib.request.Request(source, headers=pathe.ENTETES)
            with urllib.request.urlopen(requete, timeout=10) as reponse:
                return Image.open(io.BytesIO(reponse.read())).convert("RGB")
        chemin = xbmcvfs.translatePath(source)
        if os.path.exists(chemin):
            return Image.open(chemin).convert("RGB")
    except Exception as erreur:
        xbmc.log("[%s] image illisible : %s" % (NOM, erreur), xbmc.LOGWARNING)
    return None


def _affiche_arrondie(source, cache, largeur=400):
    """Recadre l'affiche au ratio du skin et arrondit ses coins.

    Composer plutot qu'etirer : la source n'est pas toujours une affiche. Quand
    l'element n'en a pas, Kodi rend un `thumb` en 16:9, et le forcer dans une
    boite portrait l'ecrasait. On recadre donc au centre, ce qui garde les
    proportions quoi qu'on recoive — et on arrondit dans l'image elle-meme,
    ce qui evite un masque a recaler.
    """
    image = _charger_image(source)
    if image is None:
        return ""
    try:
        from PIL import Image, ImageDraw

        hauteur = int(round(largeur / RATIO_AFFICHE))
        l, h = image.size
        # recadrage central au bon rapport, sans jamais deformer
        if l / float(h) > RATIO_AFFICHE:
            nouvelle = int(round(h * RATIO_AFFICHE))
            image = image.crop(((l - nouvelle) // 2, 0, (l - nouvelle) // 2 + nouvelle, h))
        else:
            nouvelle = int(round(l / RATIO_AFFICHE))
            image = image.crop((0, (h - nouvelle) // 2, l, (h - nouvelle) // 2 + nouvelle))
        image = image.resize((largeur, hauteur), Image.LANCZOS).convert("RGBA")

        coins = Image.new("L", (largeur, hauteur), 0)
        t = ImageDraw.Draw(coins)
        rayon = max(8, largeur // 14)
        try:
            t.rounded_rectangle((0, 0, largeur - 1, hauteur - 1), radius=rayon, fill=255)
        except AttributeError:
            t.rectangle((0, 0, largeur - 1, hauteur - 1), fill=255)
        image.putalpha(coins)

        chemin = os.path.join(cache, _nom_cache("affiche", source))
        if not os.path.exists(chemin):
            image.save(chemin)
            _menage_cache(cache, "affiche")
        return chemin
    except Exception as erreur:
        xbmc.log("[%s] affiche non composee : %s" % (NOM, erreur), xbmc.LOGWARNING)
        return ""


def _carte_qr(url, cache):
    """Compose le QR sur une carte blanche bordee de rose, coins arrondis.

    Tout est dessine ici plutot que confie au skin : l'extension doit rester
    lisible sous n'importe quel habillage, et un QR a besoin de sa marge blanche
    pour etre lu — la poser nous-memes evite d'en dependre.
    """
    try:
        from PIL import Image, ImageDraw

        import qrcode

        code = qrcode.QRCode(border=2, box_size=10,
                             error_correction=qrcode.constants.ERROR_CORRECT_M)
        code.add_data(url)
        code.make(fit=True)
        image = code.make_image(fill_color="black", back_color="white").convert("RGB")
        image = image.resize((COTE - 56, COTE - 56), Image.NEAREST)

        carte = Image.new("RGBA", (COTE, COTE), (0, 0, 0, 0))
        dessin = ImageDraw.Draw(carte)
        rayon = 34
        boite = (0, 0, COTE - 1, COTE - 1)
        try:
            dessin.rounded_rectangle(boite, radius=rayon, fill=(255, 255, 255, 255),
                                     outline=ROSE_FOCUS + (255,), width=6)
        except AttributeError:
            # Pillow ancien : un rectangle droit fait l'affaire
            dessin.rectangle(boite, fill=(255, 255, 255, 255),
                             outline=ROSE_FOCUS + (255,), width=6)
        carte.paste(image, (28, 28))

        chemin = os.path.join(cache, _nom_cache("qr", url))
        if not os.path.exists(chemin):
            carte.save(chemin)
            _menage_cache(cache, "qr")
        return chemin
    except Exception as erreur:  # PIL absent, disque plein, etc.
        xbmc.log("[%s] QR impossible : %s" % (NOM, erreur), xbmc.LOGWARNING)
        return None


def montrer_seances(titres, annee, art=None, plot=None):
    """Le parcours complet, depuis le menu contextuel."""
    salles = salles_choisies()
    if not salles:
        xbmcgui.Dialog().ok(NOM, _t(32004))
        ADDON.openSettings()
        return

    cache = dossier_donnees()
    progres = xbmcgui.DialogProgressBG()
    progres.create(NOM, _t(32002))
    try:
        film, fiche, ou = pathe.chercher(titres, annee, salles, cache)
    except pathe.ErreurReseau as erreur:
        progres.close()
        xbmcgui.Dialog().ok(NOM, "%s\n\n%s" % (_t(32005), erreur))
        return
    finally:
        progres.close()

    if not film:
        xbmcgui.Dialog().ok(NOM, "%s\n\n%s" % (_t(32001), titres[0] if titres else ""))
        return

    # la fiche de chaque salle donne son vrai nom ET sa grille tarifaire ; elle
    # est relue chaque jour, donc une hausse ou une offre suit d'elle-meme
    fiches_salles = {}
    for salle in ou:
        try:
            fiches_salles[salle] = pathe.cinema(salle, cache)
        except pathe.ErreurReseau:
            fiches_salles[salle] = {}

    # un meme film passe souvent dans plusieurs salles ; on regroupe par jour,
    # sinon la liste depasse la centaine d'entrees et devient inutilisable
    montrer_vost = vostfr_visible()
    ecartees = 0
    par_jour = {}
    for salle in ou:
        try:
            jours = pathe.horaires(film, salle, cache)
        except pathe.ErreurReseau:
            continue
        detail = fiches_salles.get(salle) or {}
        nom_salle = _nom_court(detail.get("name") or salle)
        for jour, seances in jours.items():
            for seance in seances:
                if not montrer_vost and (seance.get("version") or "").lower() != "vf":
                    ecartees += 1
                    continue
                par_jour.setdefault(jour, []).append(
                    (seance, nom_salle if len(ou) > 1 else None, detail))

    if not par_jour:
        # distinguer « pas de seance » de « seulement en VOSTFR, et vous les
        # masquez » : sans cela, le film paraitrait absent de l'affiche
        message = _t(32006) if ecartees else _t(32001)
        xbmcgui.Dialog().ok(NOM, "%s\n\n%s" % (message, titres[0] if titres else ""))
        return

    titre_liste = fiche.get("title") or (titres[0] if titres else "")

    # l'affiche et le synopsis viennent de l'element d'origine : la mediatheque
    # et TMDbHelper les ont deja, en meilleure qualite et dans la bonne langue
    # de quelle salle vient la seance : on le retrouve dans le regroupement
    _origine = {}
    for _j, _liste in par_jour.items():
        for _s, _nom, _detail in _liste:
            _origine[id(_s)] = (_nom, _detail)

    def _salle_de(s):
        return _origine.get(id(s), (None, None))[0]

    def _detail_de(s):
        return _origine.get(id(s), (None, None))[1]

    def _sur_choix(seance):
        """Appele par la fenetre a chaque seance retenue, sans la fermer."""
        url = seance.get("refCmd")
        if not url:
            xbmcgui.Dialog().ok(NOM, _t(32001))
            return
        chemin = _carte_qr(url, cache)
        if chemin:
            jour = (seance.get("time") or "")[:10]
            heure = (seance.get("time") or "")[11:16]
            fenetre.montrer_qr(
                ADDON.getAddonInfo("path"), chemin,
                titre_liste,
                _t(32003),
                _soustitre(seance, _salle_de(seance), _detail_de(seance)),
                "%s  ·  %s" % (_jour_lisible(jour), heure))
        else:
            # sans QR, l'URL en clair reste utilisable : on la recopie a la main
            xbmcgui.Dialog().textviewer(_t(32003), url)

    fenetre.ouvrir(
        ADDON.getAddonInfo("path"),
        titre_liste,
        _affiche_arrondie(art, cache) or art or "",
        plot or fiche.get("synopsis") or "",
        par_jour=par_jour,
        jours=sorted(par_jour),
        libelle_jour=_jour_lisible,
        date_courte=_date_courte,
        ligne=lambda s, nom: _ligne(s, None),
        detail=lambda s, nom: _detail_tuile(s, nom),
        soustitre=_soustitre,
        entete_jours=_t(32020),
        sur_choix=_sur_choix,
    )
