# -*- coding: utf-8 -*-
"""Point d'entree du script.

Sans argument : ouvre les reglages. Avec « salles » : ouvre la liste a cocher,
appelee depuis le bouton des reglages.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "resources", "lib"))
import interface  # noqa: E402

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "salles":
        interface.choisir_salles()
    else:
        import xbmcaddon
        xbmcaddon.Addon().openSettings()
