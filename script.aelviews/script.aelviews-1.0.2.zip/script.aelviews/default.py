# -*- coding: utf-8 -*-
"""Assign a view and a widget style to each AEL console.

Why a dialog rather than an ordinary skin setting: the only thing the skin can
test at runtime is the launID present in the AEL folder URL, and that identifier
is a hash created by AEL when the launcher is added. It cannot be written into
the skin in advance, nor compared against a list held in a setting: Kodi does not
interpolate a dynamic value inside a condition. The rules must be written out,
one per launcher. This dialog writes them.

Three places are touched, and they must be kept in step:

  <skin>/shortcuts/skinviewtypes.json    the rule: a condition on the launID, and
                                         the view it selects by default
  <skin>/1080i/Includes_Items.xml        the matching value in the
                                         Items_ViewMode_Switch variable
  addon_data/script.skinvariables/nodes/<skin>/...globalwidgets.json
                                         the console's widget style

The generic "ael-roms" rule must in addition exclude every console handled here:
otherwise its conditions stay true alongside the specific rule, and the lowest
view number wins — landscape box art ends up stretched into a portrait cell.

  RunScript(script.aelviews)
"""
import json
import os
import re
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()


def T(ident):
    """A translated label. Nothing is hard-coded: this add-on is meant to be
    shared, so it must speak the language of whoever installs it."""
    return ADDON.getLocalizedString(ident)


# --- what we know how to offer ------------------------------------------------
# the numbers are those of the skin's views
VIEWS = [(30003, "61"), (30004, "62"), (30005, "63")]
WIDGETS = ["Poster", "LandscapePoster", "Square", "Quad", "Card", "Banner", "Icon"]

BASE_COND = ("Container.Content() + "
             "String.Contains(Container.FolderPath,advanced.emulator.launcher)")
GENERIC = "ael-roms"


def path_of(special):
    return xbmcvfs.translatePath(special)


def dialog():
    return xbmcgui.Dialog()


def read_launchers(cats):
    """Name and launID of every launcher declared in AEL."""
    if not os.path.isfile(cats):
        return []
    return [(e.findtext("m_name") or "", e.findtext("id") or "")
            for e in ET.parse(cats).getroot() if e.tag == "launcher"]


def rule_key(lid):
    """One rule per launcher, named after its identifier.

    The key is deliberately not derived from the console name: two consoles can
    have similar names, and renaming one would break the association."""
    return "ael-roms-{}".format(lid[:6])


def generic_condition(launchers):
    negations = "".join(
        " + !String.Contains(Container.FolderPath,launID={})".format(i)
        for _, i in launchers)
    return "{} + String.Contains(Container.FolderPath,com=SHOW_ROMS){}".format(
        BASE_COND, negations)


def current_view(views_json, lid):
    """The view number in force for this launcher, generic rule included."""
    d = json.load(open(views_json, encoding="utf-8"))
    rules = d.get("rules", {})
    marker = "launID={}".format(lid)
    for k, v in rules.items():
        if k != GENERIC and marker in (v.get("rule") or ""):
            return v.get("library")
    return (rules.get(GENERIC) or {}).get("library")


def current_widget(nodes, lid):
    """This launcher's widget style, if it has one."""
    if not os.path.isdir(nodes):
        return None
    for f in sorted(os.listdir(nodes)):
        if not f.endswith("globalwidgets.json"):
            continue
        for e in json.load(open(os.path.join(nodes, f), encoding="utf-8")):
            if "launID={}".format(lid) in (e.get("path") or ""):
                return e.get("widget_style")
    return None


# --- writing the three places -------------------------------------------------
def write_rule(views_json, launchers, lid, view):
    d = json.load(open(views_json, encoding="utf-8"))
    rules = d["rules"]
    template = rules.get(GENERIC) or next(iter(rules.values()))
    key = rule_key(lid)
    # A console may already carry a rule under another name — the first ones were
    # written by hand as "ael-roms-gamecube" and the like. Two rules targeting the
    # same launID stay true together, and the lowest view number wins: the old one
    # would cancel the new one out.
    marker = "launID={}".format(lid)
    removed = [k for k, v in rules.items()
               if k not in (GENERIC, key) and marker in (v.get("rule") or "")]
    for k in removed:
        del rules[k]
    r = json.loads(json.dumps(template))
    r["rule"] = "{} + String.Contains(Container.FolderPath,launID={})".format(BASE_COND, lid)
    r["library"] = r["plugins"] = view
    rules[key] = r
    if GENERIC in rules:
        rules[GENERIC]["rule"] = generic_condition(launchers)
    json.dump(d, open(views_json, "w", encoding="utf-8"), ensure_ascii=False, indent=4)
    return key, removed


def write_condition(items, lid, key):
    """Insert the value before the generic rule, which stays the last resort."""
    t = open(items, encoding="utf-8").read()
    marker_text = "launID={}".format(lid)
    anchor = re.search(r'([ \t]*)<value condition="[^"]*com=SHOW_ROMS\)">ael-roms</value>\n', t)
    if not anchor:
        return False
    cond = "{} + String.Contains(Container.FolderPath,launID={})".format(BASE_COND, lid)
    new_line = '{}<value condition="{}">{}</value>\n'.format(anchor.group(1), cond, key)
    # remove any previous value for this launcher first
    t = re.sub(r'[ \t]*<value condition="[^"]*{}[^"]*">[^<]*</value>\n'.format(re.escape(marker_text)),
               "", t)
    anchor = re.search(r'([ \t]*)<value condition="[^"]*com=SHOW_ROMS\)">ael-roms</value>\n', t)
    t = t[:anchor.start()] + new_line + t[anchor.start():]
    open(items, "w", encoding="utf-8").write(t)
    return True


def write_widget(node, lid, style):
    if not os.path.isfile(node):
        return False
    d = json.load(open(node, encoding="utf-8"))
    touched = False
    for e in d:
        if "launID={}".format(lid) in (e.get("path") or ""):
            e["widget_style"] = style
            touched = True
    if touched:
        json.dump(d, open(node, "w", encoding="utf-8"), ensure_ascii=False, indent=4)
    return touched


def write_memory(profile, skin_id, key, view, removed):
    """The chosen view, as script.skinvariables remembers it.

    This is the fourth place, and the most treacherous: a value put here by an
    earlier choice overrides the rule's default. Without updating it, you change
    the default and nothing moves on screen."""
    f = os.path.join(profile, "addon_data", "script.skinvariables",
                     "{}-viewtypes.json".format(skin_id))
    if not os.path.isfile(f):
        return False
    d = json.load(open(f, encoding="utf-8"))
    for section in ("library", "plugins"):
        if section not in d:
            continue
        d[section][key] = view
        for k in removed:
            d[section].pop(k, None)
    json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=4)
    return True


# --- flow ---------------------------------------------------------------------
def run():
    skin = path_of("special://skin/")
    profile = path_of("special://profile/")
    cats = os.path.join(profile, "addon_data",
                        "plugin.program.advanced.emulator.launcher", "categories.xml")
    views_json = os.path.join(skin, "shortcuts", "skinviewtypes.json")
    items = os.path.join(skin, "1080i", "Includes_Items.xml")
    skin_id = os.path.basename(os.path.normpath(skin))

    launchers = read_launchers(cats)
    if not launchers:
        dialog().ok(ADDON.getAddonInfo("name"), T(30007))
        return
    for p in (views_json, items):
        if not os.path.isfile(p):
            dialog().ok(ADDON.getAddonInfo("name"), "{}[CR]{}".format(T(30008), p))
            return

    nodes = os.path.join(profile, "addon_data", "script.skinvariables", "nodes", skin_id)
    view_label = dict((n, T(l)) for l, n in VIEWS)

    # show what is currently assigned: without it one chooses blind
    lines = []
    for n, i in launchers:
        v0 = current_view(views_json, i)
        w0 = current_widget(nodes, i)
        state = view_label.get(v0, "view {}".format(v0 or "?"))
        if w0:
            state += ", " + w0
        lines.append("{}   [COLOR grey]{}[/COLOR]".format(n, state))

    i = dialog().select(T(30000), lines)
    if i < 0:
        return
    name, lid = launchers[i]

    v0 = current_view(views_json, lid)
    default_v = next((k for k, (_, n) in enumerate(VIEWS) if n == v0), -1)
    v = dialog().select("{} — {}".format(T(30001), name), [T(l) for l, _ in VIEWS],
                        preselect=default_v)
    if v < 0:
        return
    view = VIEWS[v][1]

    w0 = current_widget(nodes, lid)
    widget_choices = WIDGETS + [T(30006)]
    default_w = WIDGETS.index(w0) if w0 in WIDGETS else len(WIDGETS)
    w = dialog().select("{} — {}".format(T(30002), name), widget_choices, preselect=default_w)
    if w < 0:
        return
    style = WIDGETS[w] if w < len(WIDGETS) else None

    key, removed = write_rule(views_json, launchers, lid, view)
    write_memory(profile, skin_id, key, view, removed)
    if not write_condition(items, lid, key):
        dialog().ok(ADDON.getAddonInfo("name"), T(30009))
        return

    done = [T(30010).format(T(VIEWS[v][0]))]
    if style:
        touched = False
        if os.path.isdir(nodes):
            for f in sorted(os.listdir(nodes)):
                if f.endswith("globalwidgets.json"):
                    touched = write_widget(os.path.join(nodes, f), lid, style) or touched
        done.append(T(30011).format(style) if touched else T(30012))

    # Two distinct generations, and both are needed: buildviews for the view
    # rules, buildtemplate for the widgets. The first alone leaves the widget
    # style unchanged on screen.
    xbmc.executebuiltin("RunScript(script.skinvariables,action=buildviews,force=True)")
    xbmc.sleep(3000)
    if style:
        xbmc.executebuiltin("RunScript(script.skinvariables,action=buildtemplate,force=True)")
        xbmc.sleep(6000)
    xbmc.executebuiltin("ReloadSkin()")
    dialog().notification(ADDON.getAddonInfo("name"), "{} — {}".format(name, ", ".join(done)),
                          xbmcgui.NOTIFICATION_INFO, 5000)


if __name__ == "__main__":
    run()
