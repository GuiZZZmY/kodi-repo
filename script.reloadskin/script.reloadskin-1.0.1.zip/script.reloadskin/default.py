# -*- coding: utf-8 -*-
"""Development utility.

With no argument: reloads the skin (ReloadSkin).
With an argument: runs the Kodi builtin passed to it verbatim, which makes it
possible to trigger from outside actions JSON-RPC does not expose, for example
RunScript(script.skinvariables,action=buildviews,folder=1080i,force=True).
"""
import sys
import xbmc

builtin = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] else 'ReloadSkin()'
xbmc.log('[script.reloadskin] executebuiltin: {}'.format(builtin), xbmc.LOGINFO)
xbmc.executebuiltin(builtin)
